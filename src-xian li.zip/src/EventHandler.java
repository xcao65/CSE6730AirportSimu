//YOUR NAME HERE

public interface EventHandler {
    void handle(Event event);

}
